package com.pennant.mvc.controllers.login;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.pennant.mvc.bean.FlipkartCustomers;
import com.pennant.mvc.dao.customer.CustomerOperationsDao;
import com.pennant.mvc.dao.customer.CustomerOperationsDaoImpl;


/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/UserLoginServlet")
public class UserLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String userName = request.getParameter("username");
		String password = request.getParameter("pwd");
		HttpSession session=request.getSession();
		FlipkartCustomers customer=new FlipkartCustomers(userName, password);
		CustomerOperationsDao cust =new CustomerOperationsDaoImpl();
		boolean flag = cust.customerLogin(customer);
		if(flag){
			session.setAttribute("userName", userName);
			response.sendRedirect("home.jsp");
		}else{
			response.sendRedirect("userlogin.jsp");
		}
		
	}

}
