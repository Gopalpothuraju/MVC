package com.pennant.mvc.controller.insertprodcuts;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.pennant.mvc.bean.FlipkartCategory;
import com.pennant.mvc.bean.FlipkartProducts;
import com.pennant.mvc.dao.admin.AdminOperationsDao;
import com.pennant.mvc.dao.admin.AdminOperationsDaoImpl;


@WebServlet("/InsertProducts")
@MultipartConfig
public class InsertProducts extends HttpServlet {
	private static final long serialVersionUID = 1L;
		protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 response.setContentType("text/html;charset=UTF-8");
		 PrintWriter pw=response.getWriter();
		String productName = request.getParameter("productName");
		String productType = request.getParameter("productType");
		double price=Double.parseDouble(request.getParameter("productPrice"));
		String productBrand = request.getParameter("productBrand");
		Part photo = request.getPart("productImage");
		
		FlipkartCategory category=new FlipkartCategory(productType);
		AdminOperationsDao inserting=new AdminOperationsDaoImpl();
		int categoryId = inserting.retreiveCategoryId(category);
		FlipkartProducts product=new FlipkartProducts(productName, categoryId, price, productBrand,photo);
		
		if(inserting.insertingProducts(product)){
			pw.println("Successfully Product Inserted...");
			pw.print("<a href='insertingproducts.jsp'>click here</a>");
		}else{
			pw.println("Successfully Product Inserted...");
			pw.print("<a href='insertingproducts.jsp'>click here</a>");
		}
		
	}

}
