package com.pennant.mvc.dao.customer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.pennant.mvc.bean.FlipkartCustomers;
import com.pennant.mvc.factory.DBConnection;

public class CustomerOperationsDaoImpl implements CustomerOperationsDao{
	Connection con=null;
	public CustomerOperationsDaoImpl() {
		con=DBConnection.getConnectToDb();
	}
	@Override
	public int customerSignUp(FlipkartCustomers customer) {
		int i=0;
		String sql="insert into FLIPKART_CUSTOMERES values(FLIPKART_CUSTOMERES.nextval,?,?,?,?)";
		try {
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setString(1, customer.getUserName());
			pst.setString(2, customer.getPassword());
			pst.setString(3, customer.getEmail());
			pst.setLong(4, customer.getNumber());
			 i = pst.executeUpdate();
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return i;
	}

	@Override
	public boolean customerLogin(FlipkartCustomers customer) {
		boolean execute=false;
		String sql="select * from FLIPKART_CUSTOMERS where USERNAME=? and PASSWORD=?";
		try {
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setString(1, customer.getUserName());
			pst.setString(2, customer.getPassword());
			 execute = pst.execute();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return execute;
		
	}

}
