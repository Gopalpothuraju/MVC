package com.pennant.mvc.dao.admin;

import com.pennant.mvc.bean.Admin;
import com.pennant.mvc.bean.FlipkartCategory;
import com.pennant.mvc.bean.FlipkartProducts;

public interface AdminOperationsDao {
public abstract boolean checkAdminDetails(Admin admin);
public abstract int insertAdmin(Admin admin);
public abstract boolean insertingProducts(FlipkartProducts product);
public abstract int retreiveCategoryId(FlipkartCategory categoryName); 
}
