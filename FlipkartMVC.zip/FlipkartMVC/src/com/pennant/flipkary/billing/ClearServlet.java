package com.pennant.flipkary.billing;

import java.io.IOException;
import java.sql.Connection;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.pennant.mvc.factory.DBConnection;



/**
 * Servlet implementation class ClearServlet
 */
@WebServlet("/ClearServlet")
public class ClearServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection con = null;

	

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		con=DBConnection.getConnectToDb();
		HttpSession session = request.getSession();
		Enumeration<String> em = session.getAttributeNames();
		while (em.hasMoreElements()) {
			String string = em.nextElement();

			if (string.equalsIgnoreCase("userName")) {

			} else {
				session.removeAttribute(string);
			}
		}
		response.sendRedirect("home.jsp");
	}

}
